#!/usr/bin/env node
import { runPipeline } from './src/pipeline.js';
import { assertLiveKeys } from './src/config.js';

// Usage:
//   node run.js "Cole's Road Brewing, Wallingford CT"
//   node run.js --dry-run --facts data/sample-business.json
//   node run.js "Cole's Road Brewing" --skip-qa

function parseArgs(argv) {
  const opts = { dryRun: false, factsFile: null, skipQA: false };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--dry-run') opts.dryRun = true;
    else if (a === '--skip-qa') opts.skipQA = true;
    else if (a === '--facts') opts.factsFile = argv[++i];
    else positional.push(a);
  }
  opts.query = positional.join(' ').trim();
  return opts;
}

const opts = parseArgs(process.argv.slice(2));

if (!opts.query && !opts.factsFile) {
  console.error('Usage: node run.js "<business name>, <city ST>"  [--dry-run] [--facts <file>] [--skip-qa]');
  process.exit(1);
}

try {
  // Dry-run with a fixture needs no keys at all. Dry-run live needs Places only.
  if (!opts.factsFile) assertLiveKeys({ requirePlaces: true });
  else if (!opts.dryRun) assertLiveKeys({ requirePlaces: false });

  const result = await runPipeline(opts.query || '(from fixture)', opts);
  if (result.preview) {
    console.log('\n✓ Done. Open the preview:');
    console.log('  npm run serve   # then visit', result.preview.url);
  }
} catch (err) {
  console.error('\n✗ Pipeline error:', err.message);
  process.exit(1);
}
