// Triage runs before generation. It scores photos so only strong assets get promoted,
// and decides whether this is a "Greenfield" build (thin/no data) so the generator
// leans on type + CSS instead of missing photography.

const MIN_HERO_WIDTH = 1600; // below this, a photo isn't hero-grade

function scorePhoto(p) {
  let score = 0;
  // Source priority: Google high-res > legacy hero > yelp gallery
  if (p.source === 'google') score += 3;
  else if (p.source === 'legacy') score += 2;
  else score += 1;
  // Resolution (Google gives widthPx/heightPx; others often don't)
  if (p.widthPx) {
    if (p.widthPx >= 2400) score += 3;
    else if (p.widthPx >= MIN_HERO_WIDTH) score += 2;
    else score += 0;
  } else {
    score += 1; // unknown dimension — neutral
  }
  const heroGrade = (p.widthPx || 0) >= MIN_HERO_WIDTH || p.role === 'hero';
  return { ...p, score, heroGrade };
}

export function triage(facts) {
  const scored = (facts.assets.photos || [])
    .map(scorePhoto)
    .sort((a, b) => b.score - a.score);

  const heroCandidates = scored.filter((p) => p.heroGrade);
  const usablePhotos = scored.filter((p) => p.score >= 3);

  // Greenfield: no website AND light text signal AND few/no strong photos.
  const lightText =
    !facts.atmosphere.editorialSummary &&
    (facts.socialProof.userRatingCount || 0) < 5;
  const thinPhotos = usablePhotos.length < 2;
  const greenfield = !facts.identity.website && lightText && thinPhotos;

  return {
    ...facts,
    triage: {
      greenfield,
      heroCandidate: heroCandidates[0]?.url || null,
      rankedPhotos: scored,
      usableCount: usablePhotos.length,
      // 2–3 targeted asks the app can surface to the owner (never a blocker)
      suggestedAsks: buildAsks(facts, { greenfield, usableCount: usablePhotos.length, heroCandidates }),
    },
  };
}

function buildAsks(facts, { greenfield, usableCount, heroCandidates }) {
  const asks = [];
  if (greenfield) {
    asks.push(`I couldn't find many photos of ${facts.identity.name} online — got a few good ones on your phone?`);
  } else {
    if (!heroCandidates.length)
      asks.push('I found photos but none big enough for a hero banner — do you have one high-res shot of the space?');
    if (usableCount < 4)
      asks.push('A couple more interior/product photos would let me build out the gallery — want to add some?');
  }
  if (!facts.assets.logo)
    asks.push('I couldn\'t find your logo — upload it and I\'ll build the palette around it.');
  return asks.slice(0, 3);
}
