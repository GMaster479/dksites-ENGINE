import Anthropic from '@anthropic-ai/sdk';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { config } from '../config.js';
import { parseJson } from '../analyze/brand.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SPEC_PATH = join(__dirname, '..', 'rules', 'generation-spec.md');

let cachedSpec = null;
async function loadSpec() {
  if (!cachedSpec) cachedSpec = await readFile(SPEC_PATH, 'utf8');
  return cachedSpec;
}

/**
 * Build the prompt the generator sees. Exposed separately so --dry-run can print it
 * without spending a token.
 */
export async function buildGenerationPrompt(facts, decisions) {
  const spec = await loadSpec();
  const clientPrefix = slugPrefix(facts.identity.name);
  const assetList = (facts.triage?.rankedPhotos || facts.assets.photos || [])
    .slice(0, 10)
    .map((p, i) => ({ sourceUrl: p.url, suggestedPath: `images/photo-${i + 1}.webp`, heroGrade: !!p.heroGrade }));

  const user = {
    business: facts.identity,
    operational: facts.operational,
    atmosphere: facts.atmosphere,
    socialProof: { rating: facts.socialProof.rating, count: facts.socialProof.userRatingCount, reviews: facts.socialProof.reviews?.slice(0, 4) },
    designDecisions: decisions,
    greenfield: facts.triage?.greenfield ?? false,
    clientPrefix,
    assets: { logo: facts.assets.logo, favicon: facts.assets.favicon, photos: assetList },
    attributions: facts.attributions,
    pageScope: 'Build the single-page homepage (index.html) now. Note other pages in "notes".',
  };

  return {
    system: spec,
    userText:
      `Generate the site for this business. Honor every rule in the system prompt — ` +
      `especially: concrete facts above the fold, ONE signature element, committed palette, ` +
      `client-prefixed classes ("${clientPrefix}-"), and the non-negotiable floor.\n\n` +
      `INPUT:\n${JSON.stringify(user, null, 2)}`,
  };
}

export async function generateSite(facts, decisions) {
  const client = new Anthropic({ apiKey: config.anthropicKey });
  const { system, userText } = await buildGenerationPrompt(facts, decisions);

  const msg = await client.messages.create({
    model: config.genModel,
    max_tokens: 16000,
    system,
    messages: [{ role: 'user', content: userText }],
  });

  const text = msg.content.filter((b) => b.type === 'text').map((b) => b.text).join('');
  const result = parseJson(text);
  if (!result.files?.length) throw new Error('Generator returned no files.');
  return result; // { files:[{path,contents}], signature_element, notes }
}

function slugPrefix(name) {
  return (name || 'site')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 4) || 'site';
}
