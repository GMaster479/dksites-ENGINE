import { mkdir, writeFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { config } from '../config.js';

/**
 * Write a generated site to PREVIEW_DIR/<id>/ and download referenced assets so the
 * preview is self-contained and matches what will eventually ship to R2.
 * Returns { id, dir, url, written, assets }.
 */
export async function writePreview(facts, generated) {
  const id = randomUUID();
  const dir = join(config.previewDir, id);
  await mkdir(dir, { recursive: true });

  const written = [];
  for (const file of generated.files) {
    const full = join(dir, file.path);
    await mkdir(dirname(full), { recursive: true });
    await writeFile(full, file.contents, 'utf8');
    written.push(file.path);
  }

  // Download assets the generator referenced (best-effort).
  const assetMap = (facts.triage?.rankedPhotos || facts.assets.photos || [])
    .slice(0, 10)
    .map((p, i) => ({ url: p.url, path: `images/photo-${i + 1}.webp` }));
  if (facts.assets.logo) assetMap.push({ url: facts.assets.logo, path: 'images/logo.png' });
  if (facts.assets.favicon) assetMap.push({ url: facts.assets.favicon, path: 'favicon.ico' });

  const assets = [];
  await mkdir(join(dir, 'images'), { recursive: true });
  for (const a of assetMap) {
    try {
      const res = await fetch(a.url, { signal: AbortSignal.timeout(20000) });
      if (!res.ok) { assets.push({ path: a.path, ok: false, status: res.status }); continue; }
      const buf = Buffer.from(await res.arrayBuffer());
      const full = join(dir, a.path);
      await mkdir(dirname(full), { recursive: true });
      await writeFile(full, buf);
      assets.push({ path: a.path, ok: true, bytes: buf.length });
    } catch (e) {
      assets.push({ path: a.path, ok: false, error: String(e.message || e) });
    }
  }

  // Persist the full facts + decisions sidecar for auditing / app editing.
  await writeFile(join(dir, '_build.json'), JSON.stringify({ facts, generated }, null, 2));

  return {
    id,
    dir,
    url: `${config.previewBaseUrl}/${id}/`,
    written,
    assets,
  };
}
