import 'dotenv/config';

function need(name) {
  const v = process.env[name];
  if (!v || v.startsWith('AIza') === false && name === 'GOOGLE_PLACES_KEY' && v.includes('xxxx')) {
    // soft check only; real validation happens at call sites
  }
  return v;
}

export const config = {
  anthropicKey: process.env.ANTHROPIC_API_KEY || '',
  googlePlacesKey: process.env.GOOGLE_PLACES_KEY || '',
  yelpKey: process.env.YELP_API_KEY || '',

  brandModel: process.env.BRAND_MODEL || 'claude-sonnet-4-6',
  genModel: process.env.GEN_MODEL || 'claude-sonnet-4-6',
  triageModel: process.env.TRIAGE_MODEL || 'claude-haiku-4-5-20251001',

  previewBaseUrl: process.env.PREVIEW_BASE_URL || 'http://localhost:8787',
  previewDir: process.env.PREVIEW_DIR || './previews',
  port: parseInt(process.env.PORT || '8787', 10),
};

/** Throw early with a clear message if a required key for live mode is missing. */
export function assertLiveKeys({ requirePlaces = true } = {}) {
  const missing = [];
  if (!config.anthropicKey || config.anthropicKey.includes('xxxx')) missing.push('ANTHROPIC_API_KEY');
  if (requirePlaces && (!config.googlePlacesKey || config.googlePlacesKey.includes('xxxx')))
    missing.push('GOOGLE_PLACES_KEY');
  if (missing.length) {
    throw new Error(
      `Missing required env vars: ${missing.join(', ')}.\n` +
        `Copy .env.example to .env and fill them in, or run with --dry-run to skip live calls.`
    );
  }
}
