import Anthropic from '@anthropic-ai/sdk';
import { config } from '../config.js';

// Stage 2: turn facts into an explicit, reviewable set of DESIGN DECISIONS before any
// code is written. This intermediate artifact is what makes the brand sheet editable in
// the app and lets you audit *why* the generator chose what it chose.

const BRAND_SYSTEM = `You are the brand-direction stage of the DK Sites pipeline.
Given structured facts about ONE local business, make deliberate design decisions in the
DK Sites house style. You are NOT writing code yet — you are committing to a direction.

Rules you must honor:
- Palette: COMMIT. Derive from the logo/photos/legacy colors when present. Flexible count
  (2 strong colors or up to 5 committed jewel tones) but never a timid hedge of near-grays.
- Anti-convergence: tone-to-trade sets the register, the brand sets the key. Pick a
  distinctive key for THIS business; do not reach for the obvious default for its category.
- Typography: one display face + one workhorse body (Google Fonts), with a one-line reason.
- Tone: match the trade as a starting register, then deviate for the brand's personality.
- Signature element: invent ONE custom visual device expressing what this business
  physically does, implementable in CSS/canvas within a performance budget. Mandatory.
- If greenfield (thin data), bias toward typographic + geometric CSS design over photography.

Respond with ONLY a JSON object, no prose, no markdown fences:
{
  "palette": { "dominant": "#hex", "accent": "#hex", "neutrals": ["#hex"], "rationale": "" },
  "typography": { "display": "Font Name", "body": "Font Name", "rationale": "" },
  "tone": "2-4 words (e.g. 'calm, clinical, warm')",
  "register": "the trade register you started from",
  "signature_element": { "concept": "", "implementation": "CSS or canvas approach" },
  "layout": { "structure": "ordered list of homepage sections", "components_from_attributes": [] },
  "voice": "1 sentence on copy voice",
  "above_the_fold_facts": ["which concrete facts to surface in/near the hero"]
}`;

export async function analyzeBrand(facts) {
  const client = new Anthropic({ apiKey: config.anthropicKey });
  const payload = compactFacts(facts);

  const msg = await client.messages.create({
    model: config.brandModel,
    max_tokens: 1500,
    system: BRAND_SYSTEM,
    messages: [
      {
        role: 'user',
        content: `Business facts (JSON):\n${JSON.stringify(payload, null, 2)}\n\nMake the design decisions.`,
      },
    ],
  });

  const text = msg.content.filter((b) => b.type === 'text').map((b) => b.text).join('');
  return parseJson(text);
}

// Trim the facts to what brand direction actually needs (keeps tokens/cost down).
function compactFacts(f) {
  return {
    name: f.identity.name,
    primaryType: f.atmosphere.primaryType,
    primaryTypeDisplayName: f.atmosphere.primaryTypeDisplayName,
    editorialSummary: f.atmosphere.editorialSummary,
    attributes: f.atmosphere.attributes,
    priceLevel: f.operational.priceLevel,
    rating: f.socialProof.rating,
    reviewSample: (f.socialProof.reviews || []).slice(0, 3).map((r) => r.text),
    legacyColors: (f.assets.legacyColors || []).map((c) => c.hex),
    hasLogo: !!f.assets.logo,
    greenfield: f.triage?.greenfield ?? false,
    usablePhotoCount: f.triage?.usableCount ?? 0,
  };
}

export function parseJson(text) {
  const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end !== -1) return JSON.parse(cleaned.slice(start, end + 1));
    throw new Error('Brand stage did not return parseable JSON:\n' + text.slice(0, 500));
  }
}
